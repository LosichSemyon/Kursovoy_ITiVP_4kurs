history_repairs TRUNCATE autoservice.News;
SELECT*FROM autoservice.News;
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    review_text TEXT NOT NULL,
    rating INT NOT NULL,
    review_date DATE NOT NULL
);
-- Вставка тестового отзыва 1
INSERT INTO reviews (username, review_text, rating, review_date) values
('JohnDoe', 'Great service! Very satisfied with the experience.', 5, '2023-01-01'),
('AliceSmith', 'Could be better. Some improvements needed.', 3, '2023-01-05'),
('BobJohnson', 'Average service. Nothing special.', 2, '2023-01-10'),
('EvaWilliams', 'Excellent! I would highly recommend it.', 5, '2023-01-15'),
('SamMiller', 'Not satisfied at all. Poor experience.', 1, '2023-01-20');
CREATE TABLE services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL
);
INSERT INTO services (service_name, description, price) VALUES
('Услуга 1', 'Описание услуги 1', 50.00),
('Услуга 2', 'Описание услуги 2', 75.00),
('Услуга 3', 'Описание услуги 3', 100.00),
('Услуга 4', 'Описание услуги 4', 120.00),
('Услуга 5', 'Описание услуги 5', 90.00),
('Услуга 6', 'Описание услуги 6', 60.00),
('Услуга 7', 'Описание услуги 7', 110.00),
('Услуга 8', 'Описание услуги 8', 80.00),
('Услуга 9', 'Описание услуги 9', 95.00),
('Услуга 10', 'Описание услуги 10', 70.00),
('Услуга 11', 'Описание услуги 11', 85.00),
('Услуга 12', 'Описание услуги 12', 130.00);NewsNews