DELIMITER //
CREATE TRIGGER after_insert_user
AFTER INSERT ON users
FOR EACH ROW
BEGIN
    INSERT INTO roles (username, role) VALUES (NEW.username, 'unset');
END;
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER after_delete_user
AFTER DELETE ON users
FOR EACH ROW
BEGIN
    DELETE FROM roles WHERE username = OLD.username;
END;
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER after_update_user
AFTER UPDATE ON users
FOR EACH ROW
BEGIN
    IF NEW.role <> OLD.role THEN
        UPDATE roles SET role = NEW.role WHERE username = NEW.username;
    END IF;
END;
//
DELIMITER ;
