CREATE TABLE car_errors (
  id INT PRIMARY KEY,
  error_code VARCHAR(10),
  error_name VARCHAR(100),
  error_description TEXT
);

INSERT INTO car_errors (id, error_code, error_name, error_description) VALUES
(1, 'P0016', 'Crankshaft Position - Camshaft Position Correlation (Bank 1 Sensor A)', 'The powertrain control module (PCM) has detected a misalignment between the crankshaft and camshaft positions for bank 1 sensor A.'),
(2, 'P0171', 'System Too Lean (Bank 1)', 'The powertrain control module (PCM) has detected a lean air/fuel mixture for bank 1.'),
(3, 'P0300', 'Random/Multiple Cylinder Misfire Detected', 'The powertrain control module (PCM) has detected misfires in multiple cylinders.'),
(4, 'P0420', 'Catalyst System Efficiency Below Threshold (Bank 1)', 'The powertrain control module (PCM) has detected that the catalytic converter is not operating efficiently for bank 1.'),
(5, 'P0455', 'Evaporative Emission System Leak Detected (Large Leak)', 'The powertrain control module (PCM) has detected a large leak in the evaporative emission control system.'),
(6, 'P0562', 'System Voltage Low', 'The powertrain control module (PCM) has detected that the system voltage is below the specified threshold.'),
(7, 'P0700', 'Transmission Control System Malfunction', 'The powertrain control module (PCM) has detected a malfunction in the transmission control system.'),
(8, 'P1128', 'Closed Loop Fueling Not Achieved - Bank 1', 'The powertrain control module (PCM) has detected that the fuel system is not operating in closed loop mode for bank 1.'),
(9, 'P1131', 'Lack of Upstream Heated Oxygen Sensor Switch - Sensor Indicates Lean - Bank 1', 'The powertrain control module (PCM) has detected that the upstream heated oxygen sensor is indicating a lean air/fuel mixture for bank 1.'),
(10, 'P1234', 'Turbocharger Boost Control Position Exceeded Learning Limit', 'The powertrain control module (PCM) has detected that the turbocharger boost control position has exceeded the learning limit.'),
(11, 'P1400', 'DPFE Sensor Circuit Low Voltage Detected', 'The powertrain control module (PCM) has detected a low voltage condition in the DPFE (differential pressure feedback EGR) sensor circuit.'),
(12, 'P1443', 'Evaporative Emission Control System Control Valve', 'The powertrain control module (PCM) has detected a malfunction in the evaporative emission control system control valve.'),
(13, 'P1518', 'Intake Manifold Runner Control (IMRC) Circuit Open', 'The powertrain control module (PCM) has detected an open circuit in the intake manifold runner control (IMRC) circuit.'),
(14, 'P1633', 'Keep Alive Power Voltage Too Low', 'The powertrain control module (PCM) has detected that the keep alive power voltage is too low.'),
(15, 'P1780', 'Transmission Control Switch Out of Self-Test Range', 'The powertrain control module (PCM) has detected that the transmission control switch is out of the self-test range.'),
(16, 'P2004', 'Intake Manifold Runner Control (IMRC) Stuck Open (Bank 1)', 'The powertrain control module (PCM) has detected that the intake manifold runner control (IMRC) is stuck open for bank 1.'),
(17, 'P2104', 'Throttle Actuator Control System - Forced Idle', 'The powertrain control module (PCM) has detected a forced idle condition in the throttle actuator control system.'),
(18, 'P2135', 'Throttle/Pedal Position Sensor/Switch A/B Voltage Correlation', 'The powertrain control module (PCM) has detected a voltage correlation problem between the throttle position sensor and the pedal position sensor/switch.'),
(19, 'P2195', 'O2 Sensor Signal Stuck Lean (Bank 1 Sensor 1)', 'The powertrain control module (PCM) has detected that the oxygen sensor signal for bank 1 sensor 1 is stuck lean.'),
(20, 'P2251', 'O2 Sensor Negative Current Control Circuit/Open (Bank 1 Sensor 1)', 'The powertrain control module (PCM) has detected an open circuit or a fault in the negative current control circuit for bank 1 sensor 1.'),
(21, 'P2299', 'Brake Pedal Position/Accelerator Pedal Position Incompatible', 'The powertrain control module (PCM) has detected an incompatible relationship between the brake pedal position and the accelerator pedal position.'),
(22, 'P2402', 'EVAP Leak Detection Pump Control Circuit High', 'The powertrain control module (PCM) has detected a high voltage condition in the EVAP leak detection pump control circuit.'),
(23, 'P2646', 'A Rocker Arm Actuator System Performance or Stuck Off (Bank 1)', 'The powertrain control module (PCM) has detected a performance problem or a stuck off condition in the rocker arm actuator system for bank 1.'),
(24, 'P2703', 'Transmission Friction Element D Apply Time Range/Performance', 'The powertrain control module (PCM) has detected a problem with the apply time range or performance of the transmission friction element D.'),
(25, 'U0100', 'Lost Communication with ECM/PCM "A"', 'The powertrain control module (PCM) has lost communication with the engine control module (ECM) or powertrain control module (PCM) "A".');