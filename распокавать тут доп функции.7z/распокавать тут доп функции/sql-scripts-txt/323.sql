DELIMITER //
CREATE TRIGGER after_insert_user
AFTER INSERT ON users
FOR EACH ROW
BEGIN
    INSERT INTO roles (username, role) VALUES (NEW.username, 'unset');
    INSERT INTO avatars (username, path) VALUES (NEW.username, 'unset');
END;
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER after_delete_user
AFTER DELETE ON users
FOR EACH ROW
BEGIN
    DELETE FROM roles WHERE username = OLD.username;
    DELETE FROM avatars WHERE username = OLD.username;
END;
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER after_update_user
AFTER UPDATE ON users
FOR EACH ROW
BEGIN
    IF NEW.role <> OLD.role THEN
        UPDATE roles SET role = NEW.role WHERE username = NEW.username;
    END IF;
END;
//
DELIMITER ;



-- Файл create_avatars_table.sql

CREATE TABLE avatars (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    path VARCHAR(255) NOT NULL
);


-- Файл trigger_delete_avatar.sql

DELIMITER //
CREATE TRIGGER after_user_delete
AFTER DELETE ON users FOR EACH ROW
BEGIN
    DELETE FROM avatars WHERE username = OLD.username;
END;
//
DELIMITER ;




-- Файл trigger_add_avatar.sql
CREATE DEFINER=`root`@`localhost` TRIGGER `after_insert_user` AFTER INSERT ON `users` FOR EACH ROW BEGIN
    INSERT INTO roles (username, role) VALUES (NEW.username, 'unset');
END
