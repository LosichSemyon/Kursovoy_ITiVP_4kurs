USE autoservice;
CREATE INDEX idx_username ON users (username);
CREATE TABLE cars (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(255),
  brand VARCHAR(50),
  license_plate VARCHAR(20),
  color VARCHAR(20),
  year INT,
  vin_number VARCHAR(50),
  FOREIGN KEY (username) REFERENCES users(username)
);