CREATE TABLE autoservice.roles (
    username VARCHAR(255) PRIMARY KEY,
    role VARCHAR(255)
);
