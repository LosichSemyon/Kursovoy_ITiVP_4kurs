SELECT*FROM users;
TRUNCATE users;
TRUNCATE roles;
CREATE TABLE history_repairs (
   `id_repair` INT(10) NOT NULL ,
	`mech_name` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_0900_ai_ci',
	`manager_name` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_0900_ai_ci',
	`client_name` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_0900_ai_ci',
	`car_brand` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_0900_ai_ci',
	`vin_number` VARCHAR(17) NULL DEFAULT NULL COLLATE 'utf8mb4_0900_ai_ci',
	`start_date` DATE NULL DEFAULT NULL,
	`finish_date` DATE NULL DEFAULT NULL,
	`cost` DECIMAL(10,2) NULL DEFAULT NULL,
	`status` INT(10) NULL DEFAULT '0'
);
INSERT INTO history_repairs (mech_name, manager_name, client_name, car_brand, vin_number, start_date, finish_date, cost, STATUS)
VALUES
('Mechanic 1', 'Manager 1', 'Client 1', 'Brand 1', 'VIN12345678901234', '2023-01-01 10:00:00', '2023-01-02 15:30:00', 500.00, 1),
('Mechanic 2', 'Manager 2', 'Client 2', 'Brand 2', 'VIN23456789012345', '2023-02-01 09:30:00', '2023-02-02 18:45:00', 700.00, 2),
('Mechanic 3', 'Manager 1', 'Client 3', 'Brand 3', 'VIN34567890123456', '2023-03-01 11:15:00', null, 600.00, 0),
('Mechanic 1', 'Manager 2', 'Client 4', 'Brand 1', 'VIN45678901234567', '2023-04-01 14:45:00', '2023-04-02 12:30:00', 800.00, 3),
('Mechanic 2', 'Manager 2', 'Client 5', 'Brand 2', 'VIN56789012345678', '2023-05-01 08:00:00', null, 900.00, 1);
INSERT INTO history_repairs (mech_name, manager_name, client_name, car_brand, vin_number, start_date, finish_date, cost, status)
VALUES ('mech', 'manager', 'testuser1', 'Toyota', '123456789', '2023-01-01', '2023-01-10', 500.00, 1);

-- Создание таблицы текущих ремонтов
CREATE TABLE current_repairs (
    id_repair INT PRIMARY KEY AUTO_INCREMENT,
    mech_name VARCHAR(255),
    manager_name VARCHAR(255),
    client_name VARCHAR(255),
    car_brand VARCHAR(255),
    vin_number VARCHAR(17),
    start_date DATE,
    finish_date DATE,
    cost DECIMAL(10, 2),
    status INT DEFAULT 0
);
INSERT INTO current_repairs (mech_name, manager_name, client_name, car_brand, vin_number, start_date, finish_date, cost, status)
VALUES 
('Mechanic1', 'manager', 'Client1', 'Brand1', 'VIN1', '2023-01-01', '2023-01-10', 500, 0);
('Mechanic2', 'Manager2', 'Client2', 'Brand2', 'VIN2', '2023-02-01', '2023-02-15', 700, 1),
('Mechanic3', 'Manager3', 'Client3', 'Brand3', 'VIN3', '2023-03-01', '2023-03-20', 900, 2);
after_insert_user