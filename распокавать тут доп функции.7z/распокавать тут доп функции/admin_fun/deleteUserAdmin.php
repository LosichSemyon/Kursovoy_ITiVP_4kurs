<?php
require_once '../database_config.php';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];

    // Запрос на удаление аккаунта пользователя из таблицы "users"
    $sql = "DELETE FROM users WHERE username = '$username'";

    if ($conn->query($sql) === TRUE) {
        $message = "Аккаунт пользователя $username успешно удален";
        echo "<script>
                alert('$message');
                window.location.href = 'deleteUserAdminMain.php';
              </script>";
    } else {
        $error = "Ошибка при удалении аккаунта: " . $conn->error;
        echo "<script>
                alert('$error');
                window.location.href = 'deleteUserAdminMain.php';
              </script>";
    }
}

$conn->close();
?>