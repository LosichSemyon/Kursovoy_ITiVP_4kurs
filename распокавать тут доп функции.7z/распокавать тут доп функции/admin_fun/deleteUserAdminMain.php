<?php
require_once '../database_config.php';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}
if (isset($_GET['show_all'])) {
    $sql = "SELECT id, username, email FROM users";
}
// Обработка поискового запроса
$search = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
}

// Запрос к базе данных для получения отфильтрованных данных из таблицы "users"
$sql = "SELECT id, username, email FROM users WHERE username LIKE '%$search%'";
$result = $conn->query($sql);

// Проверка наличия данных
if ($result->num_rows > 0) {
    // Вывод данных в виде таблицы
    echo "<table>";
    echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Удалить аккаунт</th></tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . $row["username"] . "</td>";
        echo "<td>" . $row["email"] . "</td>";
        echo "<td>";
        echo "<form method='post' action='deleteUserAdmin.php'>";
        echo "<input type='hidden' name='username' value='" . $row["username"] . "'>";
        echo "<input type='submit' value='Удалить'>";
        echo "</form>";
        echo "</td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "Нет данных в таблице";
}

$conn->close();
?>

<!-- HTML форма для ввода поискового запроса и кнопки "Найти" -->
<form method="get" action="">
    <div>
        <input type="text" name="search" placeholder="Поиск по имени">
        <input type="submit" value="Найти">
        <input type="submit" name="show_all" value="Отобразить всех">
    </div>
</form>