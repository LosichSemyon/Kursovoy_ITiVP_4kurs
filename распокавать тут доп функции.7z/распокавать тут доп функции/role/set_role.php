<?php
require_once '../database_config.php';
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["username"]) && isset($_POST["new_role"])) {
        $username = $_POST["username"];
        $newRole = $_POST["new_role"];

        // Обновление роли в базе данных
        $sql = "UPDATE roles SET role = '$newRole' WHERE username = '$username'";
        $result = $conn->query($sql);

        if ($result) {
            // JavaScript для открытия всплывающего окна с сообщением об успешном обновлении роли
            echo "<script>";
            echo "alert('Роль успешно установлена');";
            echo "window.location.href = 'role_main.php';";
            echo "</script>";
        } else {
            // JavaScript для открытия всплывающего окна с сообщением об ошибке обновления роли
            echo "<script>";
            echo "alert('Ошибка при обновлении роли: " . $conn->error . "');";
            echo "window.location.href = 'role_main.php';";
            echo "</script>";
        }

        $conn->close();
    }
}
?>