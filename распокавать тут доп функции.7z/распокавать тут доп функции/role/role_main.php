<?php
require_once '../database_config.php';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

// Обработка поискового запроса
$search = "";
$role = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
}
if (isset($_GET['role'])) {
    $role = $_GET['role'];
}

// Запрос к базе данных для получения отфильтрованных данных из таблицы "roles"
$sql = "SELECT username, role FROM roles WHERE username LIKE '%$search%'";
if (!empty($role)) {
    $sql .= " AND role = '$role'";
}

// Проверка наличия параметра "Отобразить всех"
if (isset($_GET['show_all'])) {
    $sql = "SELECT username, role FROM roles";
}

$result = $conn->query($sql);

// Проверка наличия данных
if ($result->num_rows > 0) {
    // Вывод данных в виде таблицы
    echo "<table>";
    echo "<tr><th>Username</th><th>Role</th><th>Установить роль</th></tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["username"] . "</td>";
        echo "<td>" . $row["role"] . "</td>";
        echo "<td>";
        echo "<form method='post' action='set_role.php'>";
        echo "<input type='hidden' name='username' value='" . $row["username"] . "'>";
        echo "<select name='new_role'>";
        echo "<option value='admin'>Администратор</option>";
        echo "<option value='mekchanic'>Механик</option>";
        echo "<option value='client'>Клиент</option>";
        echo "<option value='manager'>Менеджер</option>";
        echo "</select>";
        echo "<input type='submit' value='Установить'>";
        echo "</form>";
        echo "</td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "Нет данных в таблице";
}

$conn->close();
?>
<link rel="stylesheet" href="role_style.css">
<!-- HTML форма для ввода поискового запроса, кнопки "Найти" и "Отобразить всех", а также радио кнопки -->
<form method="get" action="">
    <div>
        <input type="text" name="search" placeholder="Поиск по имени">
        <input type="submit" value="Найти">
        <input type="submit" name="show_all" value="Отобразить всех">
    </div>
</form>